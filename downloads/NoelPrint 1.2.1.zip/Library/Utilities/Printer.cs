using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Utilities
{
    /// <summary>
    ///   Allows to take screenshots of whole screen,
    ///   forgeground window or a custom rectangle
    ///   using user32 windows functions.
    /// </summary>
    public static class Printer
    {
        /// <summary>
        ///   Captures the whole screen.
        /// </summary>
        public static Bitmap CaptureScreen()
        {
            return CaptureWindow(GetDesktopWindow());
        }

        /// <summary>
        ///   Captures the foreground window.
        /// </summary>
        public static Bitmap CaptureActiveWindow()
        {
            return CaptureWindow(GetForegroundWindow());
        }

        /// <summary>
        ///   Captures given window.
        /// </summary>
        public static Bitmap CaptureWindow(IntPtr window)
        {
            Rectangle rectangle = new Rectangle();

            GetWindowRect(window, out rectangle);

            rectangle.Width  -= rectangle.Left;
            rectangle.Height -= rectangle.Top;

            return CaptureArea(rectangle);
        }

        /// <summary>
        ///   Captures an area on the screen.
        /// </summary>
        public static Bitmap CaptureArea(Rectangle rectangle)
        {
            if (rectangle.Equals(Rectangle.Empty))
            {
                throw new ArgumentException("Rectangle is empty");
            }

            Bitmap   bitmap   = new Bitmap(rectangle.Width, rectangle.Height);
            Graphics graphics = Graphics.FromImage(bitmap);

            graphics.CopyFromScreen(rectangle.Location, Point.Empty, rectangle.Size);

            graphics.Dispose();

            return bitmap;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern int GetWindowRect(IntPtr hWnd, out Rectangle lpRect);
    }
}
