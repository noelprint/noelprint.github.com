using System;
using System.Collections;
using System.IO;
using System.Runtime.Serialization;

namespace Utilities
{
    /// <summary>
    ///   Wrapper for storage file.
    /// </summary>
    public abstract class SerializableFileManager<T>
    {
        protected string        Location;
        protected IFormatter    Formatter;
        protected T             Storage;

        /// <summary>
        ///   Clears storage.
        /// </summary>
        public abstract void Clear();

        /// <summary>
        ///   Reloads storage file.
        /// </summary>
        public void Reload()
        {
            Load();
        }

        /// <summary>
        ///   Saves storage in configuration file.
        /// </summary>
        public void Save()
        {
            string directory = Path.GetDirectoryName(Location);

            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            FileStream stream = new FileStream(Location, FileMode.Create);
            
            try
            {
                Formatter.Serialize(stream, Storage);
            }
            finally
            {
                stream.Close();
            }
        }

        /// <summary>
        ///   Deletes storage file.
        /// </summary>
        public void Delete()
        {
            if (!File.Exists(Location))
            {
                return;
            }

            File.Delete(Location);
        }

        /// <summary>
        ///   Loads data from file in storage if exists.
        /// </summary>
        protected void Load()
        {
            if (!File.Exists(Location))
            {
                return;
            }

            FileStream stream = new FileStream(Location, FileMode.Open);

            try
            {
                Storage = (T)Formatter.Deserialize(stream);
            }
            catch
            {
                Delete();
            }
            finally
            {
                stream.Close();
            }
        }
    }
}
