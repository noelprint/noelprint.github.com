using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Text;

namespace Utilities
{
    /// <summary>
    ///   Builds HTTP request body as form data
    ///   supporting file transfers.
    /// </summary>
    public class FormDataBuilder
    {
        public string Boundary;

        protected StringDictionary  PostData;
        protected OrderedDictionary StreamData;

        /// <summary>
        ///   Constructs with default boundary;
        /// </summary>
        public FormDataBuilder()
        {
            Boundary = "----NoelPrintFormBoundary" + BoundaryRandom();
        }

        /// <summary>
        ///   Constructs with given boundary.
        /// </summary>
        public FormDataBuilder(string boundary)
        {
            Boundary = boundary;
        }

        /// <summary>
        ///   Disposes all files.
        /// </summary>
        public void Dispose()
        {
            if (StreamData == null)
            {
                return;
            }

            object[] value;

            foreach (DictionaryEntry entry in StreamData)
            {
                value = (object[])entry.Value;
                ((Stream)value[0]).Close();
            }
        }

        /// <summary>
        ///   Adds post field.
        /// </summary>
        public void AddPost(string name, string value)
        {
            if (PostData == null)
            {
                PostData = new StringDictionary();
            }

            PostData.Add(name, value);
        }

        /// <summary>
        ///   Adds file in post data from path.
        /// </summary>
        public void AddFile(string name, string path)
        {
            FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read);

            string filename  = Path.GetFileName(path);
            string extension = Path.GetExtension(path);
            string type      = MimeTypes.TypeFromExtension(extension);

            AddFile(name, stream, filename, type);
        }

        /// <summary>
        ///   Adds file in post data from stream.
        /// </summary>
        public void AddFile(string name, Stream stream, string filename, string type)
        {
            if (StreamData == null)
            {
                StreamData = new OrderedDictionary();
            }

            StreamData.Add(name, new object[] { stream, filename, type });
        }

        /// <summary>
        ///   Builds form data and returns a memory stream.
        /// </summary>
        public MemoryStream Build()
        {
            MemoryStream stream = new MemoryStream();
            WriteTo(stream);
            return stream;
        }

        /// <summary>
        ///   Writes form data to given stream.
        /// </summary>
        public void WriteTo(Stream stream)
        {
            if (PostData == null && StreamData == null)
            {
                return;
            }

            byte[] buffer;

            if (PostData != null)
            {
                foreach (string name in PostData)
                {
                    WriteBoundaryTo(stream);
                    WriteHeaderTo(stream, name);

                    buffer = Encoding.ASCII.GetBytes(PostData[name] + Environment.NewLine);

                    stream.Write(buffer, 0, buffer.Length);
                }
            }

            if (StreamData != null)
            {
                object[] value;

                foreach (DictionaryEntry entry in StreamData)
                {
                    value = (object[])entry.Value;

                    WriteBoundaryTo(stream);

                    WriteHeaderTo(
                        stream,
                        (string)entry.Key,
                        (string)value[1],
                        (string)value[2]
                    );

                    ((Stream)value[0]).CopyTo(stream);

                    buffer = Encoding.ASCII.GetBytes(Environment.NewLine);
                    stream.Write(buffer, 0, buffer.Length);
                }
            }

            WriteBoundaryTo(stream, true);

            Dispose();
        }

        /// <summary>
        ///   Writes given name as form data to stream.
        /// </summary>
        protected void WriteHeaderTo(Stream stream, string name)
        {
            byte[] buffer = Encoding.ASCII.GetBytes(string.Format(
                "Content-Disposition: form-data; name=\"{0}\"{1}{1}", name, Environment.NewLine
            ));

            stream.Write(buffer, 0, buffer.Length);
        }

        /// <summary>
        ///   Writes given name and filename as form data to stream.
        /// </summary>
        protected void WriteHeaderTo(Stream stream, string name, string filename, string type)
        {
            byte[] buffer;

            buffer = Encoding.ASCII.GetBytes(string.Format(
                "Content-Disposition: form-data; " + "name=\"{0}\"; filename=\"{1}\"{2}",
                name, filename, Environment.NewLine
            ));

            stream.Write(buffer, 0, buffer.Length);

            buffer = Encoding.ASCII.GetBytes(string.Format(
                "Content-Type: {0}{1}{1}", name, Environment.NewLine
            ));

            stream.Write(buffer, 0, buffer.Length);
        }

        /// <summary>
        ///   Writes form boundary to stream
        ///   with final dashes or not.
        /// </summary>
        protected void WriteBoundaryTo(Stream stream, bool final = false)
        {
            string boundary = "--" + Boundary;

            if (final)
            {
                boundary += "--";
            }

            byte[] buffer = Encoding.ASCII.GetBytes(boundary + Environment.NewLine);

            stream.Write(buffer, 0, buffer.Length);
        }

        /// <summary>
        ///   Generates a random string for boundary.
        /// </summary>
        protected string BoundaryRandom()
        {
            string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            char[] chars    = new char[16];
            Random random   = new Random();

            for (int i = 0; i < chars.Length; i++)
            {
                chars[i] = alphabet[random.Next(alphabet.Length)];
            }

            return new string(chars);
        }
    }
}
