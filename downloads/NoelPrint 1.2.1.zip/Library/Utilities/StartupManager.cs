using Microsoft.Win32;
using System;

namespace Utilities
{
    /// <summary>
    ///   Manages startup launch.
    /// </summary>
    public static class StartupManager
    {
        private static string Key = @"Software\Microsoft\Windows\CurrentVersion\Run";

        /// <summary>
        ///   Returns whether given path is registered in startup.
        /// </summary>
        public static bool Registered(string name, string path)
        {
            RegistryKey key   = Registry.CurrentUser.OpenSubKey(Key, false);
            object      value = key.GetValue(name);

            if (value == null)
            {
                return false;
            }

            return (string)value == path;
        }

        /// <summary>
        ///   Registers given name with given path in startup.
        /// </summary>
        public static void Register(string name, string path)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Key, true);
            key.SetValue(name, path);
        }

        /// <summary>
        ///   Unregisters given name from startup.
        /// </summary>
        public static void Unregister(string name)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(Key, true);
            key.DeleteValue(name);
        }
    }
}
