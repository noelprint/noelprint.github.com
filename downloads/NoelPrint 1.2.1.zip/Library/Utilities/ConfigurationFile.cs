using System;
using System.Collections.Specialized;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Utilities
{
    /// <summary>
    ///   Wrapper for configuration file.
    /// </summary>
    public class ConfigurationFile : SerializableCollectionFileManager<OrderedDictionary>
    {
        protected OrderedDictionary Defaults;

        /// <summary>
        ///   Fills properties.
        /// </summary>
        public ConfigurationFile(string location)
        {
            Location  = location;
            Formatter = (IFormatter)new BinaryFormatter();
            Storage   = new OrderedDictionary();
            Defaults  = new OrderedDictionary();

            Load();
        }

        /// <summary>
        ///   Clears storage.
        /// </summary>
        public override void Clear()
        {
            Storage.Clear();
            Defaults.Clear();
        }

        /// <summary>
        ///   Sets given name and value pair in default dictionary.
        /// </summary>
        public void SetDefault(string name, object value)
        {
            Defaults[name] = value;
        }

        /// <summary>
        ///   Gets value from dictionary with fallback string.
        /// </summary>
        public object Get(string name)
        {
            if (!Storage.Contains(name))
            {
                if (!Defaults.Contains(name))
                {
                    return null;
                }

                return Defaults[name];
            }

            return Storage[name];
        }

        /// <summary>
        ///   Sets given name and value pair in dictionary.
        /// </summary>
        public void Set(string name, object value)
        {
            Storage[name] = value;
        }

        /// <summary>
        ///   Removes given item from dictionary.
        /// </summary>
        public void Remove(string name)
        {
            Storage.Remove(name);
        }
    }
}
