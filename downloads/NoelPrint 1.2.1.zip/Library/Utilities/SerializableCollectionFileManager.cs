using System;
using System.Collections;

using System.Windows.Forms;

namespace Utilities
{
    /// <summary>
    ///   Wrapper for collection storage file.
    /// </summary>
    public abstract class SerializableCollectionFileManager<T> : SerializableFileManager<T> where T : ICollection
    {
        public int Count {
            get
            {
                return Storage.Count;
            }
        }

        /// <summary>
        ///   Saves storage in configuration file if necessary.
        /// </summary>
        new public void Save()
        {
            if (Storage.Count == 0)
            {
                Delete();
            }
            else
            {
                base.Save();
            }
        }
    }
}
