using System;
using System.Collections;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Utilities
{
    [Serializable()]
    public struct HistoryItem
    {
        public DateTime DateTime;
        public string   Value;
    }

    /// <summary>
    ///   Wrapper for history file.
    /// </summary>
    public class HistoryFile : SerializableCollectionFileManager<ArrayList>
    {
        protected int Length;

        /// <summary>
        ///   Fills properties.
        /// </summary>
        public HistoryFile(string location, int length)
        {
            Location  = location;
            Formatter = new BinaryFormatter();
            Storage   = new ArrayList();
            Length    = length;

            Load();
        }

        /// <summary>
        ///   Clears storage.
        /// </summary>
        public override void Clear()
        {
            Storage.Clear();
        }

        /// <summary>
        ///   Adds given string in storage and truncates if necessary.
        /// </summary>
        public void Add(string value)
        {
            Storage.Add(new HistoryItem() { DateTime = DateTime.Now, Value = value });

            if (Storage.Count > Length)
            {
                Truncate();
            }
        }

        /// <summary>
        ///   Gets last item in storage.
        /// </summary>
        public HistoryItem Last()
        {
            return (HistoryItem)Storage[Storage.Count - 1];
        }

        /// <summary>
        ///   Gets collection to iterate through.
        /// </summary>
        public ArrayList GetCollection()
        {
            return Storage;
        }
        
        /// <summary>
        ///   Truncates collection to length.
        /// </summary>
        protected void Truncate()
        {
            while (Storage.Count > Length)
            {
                Storage.RemoveAt(0);
            }
        }
    }
}
