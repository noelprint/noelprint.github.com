using Microsoft.Win32;
using System;

namespace Utilities
{
    /// <summary>
    ///   Helper for stuff about MIME types.
    /// </summary>
    public static class MimeTypes
    {
        /// <summary>
        ///   Gets MIME type from extension.
        /// </summary>
        public static string TypeFromExtension(string extension, string fallback = "application/octet-stream")
        {
            RegistryKey key = Registry.ClassesRoot.OpenSubKey(extension);
            return GetValue(key, "Content Type", fallback);
        }

        /// <summary>
        ///   Gets extension from MIME type.
        /// </summary>
        public static string ExtensionFromType(string type, string fallback = null)
        {
            RegistryKey key = Registry.ClassesRoot.OpenSubKey(@"\MIME\Database\Content Type\" + type);
            return GetValue(key, "Extension", fallback);
        }

        /// <summary>
        ///   Gets type description from extension.
        /// </summary>
        public static string DescriptionFromExtension(string extension, string fallback = null)
        {
            RegistryKey key = Registry.ClassesRoot.OpenSubKey(extension);
            return GetValue(key, "", fallback);
        }

        /// <summary>
        ///   Gets value from registry key with fallback.
        /// </summary>
        private static string GetValue(RegistryKey key, string name, string fallback = "")
        {
            if (key == null)
            {
                return fallback;
            }

            // Get value
            object value = key.GetValue(name);

            if (value == null)
            {
                return fallback;
            }

            return (string)value;
        }
    }
}
