using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Utilities
{
    public delegate void HotKeyEventHandler(object sender, HotKeyEventArgs e);

    [Flags]
    public enum HotKeyModifiers
    {
        None     = 0,
        Alt      = 1,
        Control  = 2,
        Shift    = 4,
        Windows  = 8,
        NoRepeat = 0x4000
    }

    /// <summary>
    ///   Wrapper for user32 hot key registering
    ///   and unregistering.
    /// </summary>
    public static class HotKeyManager
    {
        private static MessageForm Form;
        private static IntPtr      Handle;
        private static int         Id;

        /// <summary>
        ///   Sets static properties.
        /// </summary>
        static HotKeyManager()
        {
            Form   = new MessageForm();
            Handle = Form.Handle;
            Id     = Form.GetHashCode();
        }

        public static event HotKeyEventHandler HotKeyPressed;

        /// <summary>
        ///   Registers given key with given modifiers
        ///   in user32 hook and returns an id
        ///   that can be provided to unregister hot key.
        /// </summary>
        public static int RegisterHotKey(HotKeyModifiers modifiers, Keys key)
        {
            RegisterHotKey(Handle, Id++, (uint)modifiers, (uint)key);

            return Id;
        }

        /// <summary>
        ///   Unregisters hot key corresponding to given id.
        /// </summary>
        public static void UnregisterHotKey(int id)
        {
            UnregisterHotKey(Handle, id);
        }

        /// <summary>
        ///   Fires hot key pressed event if exists.
        /// </summary>
        private static void OnHotKeyPressed(HotKeyEventArgs e)
        {
            if (HotKeyPressed == null)
            {
                return;
            }
            
            HotKeyPressed(null, e);
        }

        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        /// <summary>
        ///   Form handle for user32 hot key hook.
        /// </summary>
        internal class MessageForm : Form
        {
            protected const int WM_HOTKEY = 0x312;

            /// <summary>
            ///   Called in message loop, fires hot key pressed
            ///   event if message is about an hot key.
            /// </summary>
            protected override void WndProc(ref Message message)
            {
                if (message.Msg == WM_HOTKEY)
                {
                    HotKeyEventArgs e = new HotKeyEventArgs(message.LParam);
                    HotKeyManager.OnHotKeyPressed(e);
                }

                base.WndProc(ref message);
            }

            /// <summary>
            ///   Ensure the window never becomes visible.
            /// </summary>
            protected override void SetVisibleCore(bool value)
            {
                base.SetVisibleCore(false);
            }
        }
    }

    /// <summary>
    ///   Event arguments class for hot key events.
    /// </summary>
    public class HotKeyEventArgs : EventArgs
    {
        public readonly HotKeyModifiers Modifiers;
        public readonly Keys            Key;

        /// <summary>
        ///   Initializes with already existing modifiers and key.
        /// </summary>
        public HotKeyEventArgs(HotKeyModifiers modifiers, Keys key)
        {
            Modifiers = modifiers;
            Key       = key;
        }

        /// <summary>
        ///   Computes modifiers and key from user32 message param.
        /// </summary>
        public HotKeyEventArgs(IntPtr param)
        {
            Modifiers = (HotKeyModifiers)((int)param & 0xffff);
            Key       = (Keys)(((int)param >> 16) & 0xffff);
        }
    }
}
