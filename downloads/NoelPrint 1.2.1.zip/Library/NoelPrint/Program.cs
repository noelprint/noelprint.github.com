using System;
using System.Text;
using System.Windows.Forms;
using NoelPrint.Interface;
using Utilities;

namespace NoelPrint
{
    public static class Program
    {
        /// <summary>
        ///   Main entry point for the program.
        /// </summary>
        [STAThread]
        public static void Main(string[] arguments)
        {
            try
            {
                EncodeArguments(ref arguments);

                if (arguments.Length > 0)
                {
                    HandleArguments(arguments);

                    return;
                }

                Initialize();
            }
            catch (Exception e)
            {
                Alerter.Error(e.ToString());
            }
        }

        /// <summary>
        ///   Saves configuration and history and exits application.
        /// </summary>
        public static void Exit()
        {
            Configuration.Save();
            History.Save();
            Application.Exit();
        }

        /// <summary>
        ///   Initializes application.
        /// </summary>
        private static void Initialize()
        {
            RegisterHotKeys();

            HotKeyManager.HotKeyPressed += new HotKeyEventHandler(HotKeyManager_HotKeyPressed);

            TrayIcon.Show();
            
            /*
            if ((bool)Configuration.Get("ShowWelcomeMessage"))
            {
                // Show greetings message
                Greetings.Show();

                // Do not show again
                Configuration.Set("ShowWelcomeMessage", true);
            }
            */

            Application.Run();
        }

        /// <summary>
        ///   Registers application hot keys.
        /// </summary>
        private static void RegisterHotKeys()
        {
            HotKeyManager.RegisterHotKey(
                (HotKeyModifiers)Configuration.Get("HotKeys/CaptureScreen/Modifiers"),
                (Keys)Configuration.Get("HotKeys/CaptureScreen/Key")
            );

            HotKeyManager.RegisterHotKey(
                (HotKeyModifiers)Configuration.Get("HotKeys/CaptureActiveWindow/Modifiers"),
                (Keys)Configuration.Get("HotKeys/CaptureActiveWindow/Key")
            );

            HotKeyManager.RegisterHotKey(
                (HotKeyModifiers)Configuration.Get("HotKeys/CaptureArea/Modifiers"),
                (Keys)Configuration.Get("HotKeys/CaptureArea/Key")
            );
        }

        /// <summary>
        ///   Fired on hot key pressed event. Filters event
        ///   data and invokes associated action.
        /// </summary>
        private static void HotKeyManager_HotKeyPressed(
            object sender, HotKeyEventArgs e)
        {
            if (e.Modifiers == (HotKeyModifiers)Configuration.Get("HotKeys/CaptureScreen/Modifiers") &&
                e.Key       == (Keys)Configuration.Get("HotKeys/CaptureScreen/Key"))
            {
                Manager.CaptureScreen();
            }

            if (e.Modifiers == (HotKeyModifiers)Configuration.Get("HotKeys/CaptureActiveWindow/Modifiers") &&
                e.Key       == (Keys)Configuration.Get("HotKeys/CaptureActiveWindow/Key"))
            {
                Manager.CaptureActiveWindow();
            }

            if (e.Modifiers == (HotKeyModifiers)Configuration.Get("HotKeys/CaptureArea/Modifiers") &&
                e.Key       == (Keys)Configuration.Get("HotKeys/CaptureArea/Key"))
            {
                Manager.CaptureArea();
            }
        }

        /// <summary>
        ///   Executes corresponding behavior for given arguments.
        /// </summary>
        private static void HandleArguments(string[] arguments)
        {
            Alerter.Error("Fonctionnalité non implémentée.");
        }

        /// <summary>
        ///   Encodes console arguments in default encoding.
        /// </summary>
        private static void EncodeArguments(ref string[] arguments)
        {
            for (int i = 0; i < arguments.Length; i++)
            {
                arguments[i] = Encoding.Default.GetString(Encoding.Default.GetBytes(arguments[i]));
            }
        }
    }
}
