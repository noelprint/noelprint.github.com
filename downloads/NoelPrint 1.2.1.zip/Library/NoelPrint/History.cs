using System;
using System.Collections;
using Utilities;

namespace NoelPrint
{
    /// <summary>
    ///   Class to wrap history file.
    /// </summary>
    public class History
    {
       private static HistoryFile File;

        /// <summary>
        ///   Instanciates history file.
        /// </summary>
        static History()
        {
            File = new HistoryFile(
                Resources.ConfigurationPath + "\\History.bin",
                (int)Configuration.Get("History/Length")
            );
        }

        public static void Clear() { File.Clear(); }
        public static void Reload() { File.Reload(); }
        public static void Save() { File.Save(); }
        public static void Delete() { File.Delete(); }
        public static void Add(string value) { File.Add(value); }
        public static HistoryItem Last() { return File.Last(); }
        public static ArrayList GetCollection() {  return File.GetCollection(); }
    }
}
