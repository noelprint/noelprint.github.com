using Microsoft.Win32;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using Utilities;

namespace NoelPrint
{
    /// <summary>
    ///   Allows to upload files to host.
    /// </summary>
    public static class Uploader
    {
        private static string Host = "http://www.noelshack.com/api.php";
        private static string FileInputName = "fichier";
        private static Regex  Pattern = new Regex(@"www\.noelshack\.com\/(\d+)-(\d+)-(.+)");

        /// <summary>
        ///   Uploads file from path and returns
        ///   generated URL on success, or null
        ///   on error.
        /// </summary>
        public static string Upload(string path)
        {
            FormDataBuilder builder = new FormDataBuilder();
            builder.AddFile(FileInputName, path);
            return PerformRequest(builder);
        }

        public static string Upload(Image image, string name, ImageFormat format)
        {
            MemoryStream stream = new MemoryStream();
            image.Save(stream, format);
            stream.Position = 0;
            return Upload(stream, name, format);
        }

        /// <summary>
        ///   Uploads file from stream and returns
        ///   generated URL on success, or null
        ///   on error.
        /// </summary>
        public static string Upload(Stream stream, string name, ImageFormat format)
        {
            FormDataBuilder builder = new FormDataBuilder();
            builder.AddFile(FileInputName, stream, name + format.GetExtension(), format.GetMimeType());
            return PerformRequest(builder);
        }

        /// <summary>
        ///   Performs upload HTTP request and returns
        ///   generated URL on success, or null
        ///   on error.
        /// </summary>
        private static string PerformRequest(FormDataBuilder builder)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Host);

            request.Method      = WebRequestMethods.Http.Post;
            request.ContentType = "multipart/form-data; boundary=" + builder.Boundary;

            builder.WriteTo(request.GetRequestStream());

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            string body = (new StreamReader(response.GetResponseStream())).ReadToEnd();

            if (!CheckUrl(body))
            {
                return null;
            }

            return Pattern.Replace(body, "image.noelshack.com/fichiers/$1/$2/$3");
        }

        /// <summary>
        ///   Returns whether given url is valid.
        /// </summary>
        private static bool CheckUrl(string url)
        {
            try
            {
                new Uri(url);

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        ///   Performs upload HTTP request and returns
        ///   generated URL on success, or null
        ///   on error.
        /// </summary>
        private static string GetExtension(this ImageFormat format)
        {
            return MimeTypes.ExtensionFromType(format.GetMimeType());
        }

        /// <summary>
        ///   Performs upload HTTP request and returns
        ///   generated URL on success, or null
        ///   on error.
        /// </summary>
        private static string GetMimeType(this ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();
            return codecs.First(codec => codec.FormatID == format.Guid).MimeType;
        }
    }
}
