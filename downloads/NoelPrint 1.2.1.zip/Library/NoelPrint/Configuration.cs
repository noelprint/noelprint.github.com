using System;
using System.Windows.Forms;
using Utilities;

namespace NoelPrint
{
    /// <summary>
    ///   Class to wrap configuration file.
    /// </summary>
    public static class Configuration
    {
        private static ConfigurationFile File;

        /// <summary>
        ///   Instanciates configuration file.
        /// </summary>
        static Configuration()
        {
            File = new ConfigurationFile(
                Resources.ConfigurationPath + "\\Configuration.bin");

            SetConfigurationDefaults();
        }

        public static void Clear() { File.Clear(); }
        public static void Reload() { File.Reload(); }
        public static void Save() { File.Save(); }
        public static void Delete() { File.Delete(); }
        public static object Get(string name) { return File.Get(name); }
        public static void Set(string name, object value) { File.Set(name, value); }
        public static void Remove(string name) { File.Remove(name); }

        /// <summary>
        ///   Sets default values for configuration.
        /// </summary>
        private static void SetConfigurationDefaults()
        {
            File.SetDefault("HotKeys/CaptureScreen/Modifiers",       HotKeyModifiers.Control);
            File.SetDefault("HotKeys/CaptureScreen/Key",             Keys.D2);
            File.SetDefault("HotKeys/CaptureActiveWindow/Modifiers", HotKeyModifiers.Control);
            File.SetDefault("HotKeys/CaptureActiveWindow/Key",       Keys.D3);
            File.SetDefault("HotKeys/CaptureArea/Modifiers",         HotKeyModifiers.Control);
            File.SetDefault("HotKeys/CaptureArea/Key",               Keys.D4);

            File.SetDefault("History/Length",     32);
            File.SetDefault("ShowWelcomeMessage", true);
        }
    }
}
