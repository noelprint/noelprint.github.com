using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using Utilities;

namespace NoelPrint.Interface
{
    /// <summary>
    ///   Provides a tray interface for application.
    /// </summary>
    public static class TrayIcon
    {
        private static ContextMenuStrip Menu;
        private static NotifyIcon       Icon;

        /// <summary>
        ///   Initializes tray icon and menu.
        /// </summary>
        static TrayIcon()
        {
            Menu = new ContextMenuStrip();

            Menu.Items.Add(Resources.Strings.CaptureScreen,       null, new EventHandler(Menu_CaptureScreen_Click));
            Menu.Items.Add(Resources.Strings.CaptureActiveWindow, null, new EventHandler(Menu_CaptureActiveWindow_Click));
            Menu.Items.Add(Resources.Strings.CaptureArea,         null, new EventHandler(Menu_CaptureArea_Click));
            Menu.Items.Add(Resources.Strings.SaveHistory,         null, new EventHandler(Menu_SaveHistory_Click));

            ToolStripMenuItem item = new ToolStripMenuItem();

            item.CheckedChanged += Menu_RunOnStartup_CheckedChanged;

            item.Checked      = Manager.StartupRegistered();
            item.CheckOnClick = true;
            item.Text         = Resources.Strings.RunOnStartup;

            Menu.Items.Add(item);

            Menu.Items.Add(Resources.Strings.Exit, null, new EventHandler(Menu_Exit_Click));

            Icon = new NotifyIcon();

            Icon.BalloonTipClicked += new EventHandler(Icon_BalloonTipClicked);

            Icon.Icon             = Resources.Icon;
            Icon.ContextMenuStrip = Menu;
            Icon.BalloonTipTitle  = Resources.Strings.Name;
        }

        /// <summary>
        ///   Shows tray icon.
        /// </summary>
        public static void Show()
        {
            Icon.Visible = true;
        }

        /// <summary>
        ///   Hides tray icon.
        /// </summary>
        public static void Hide()
        {
            Icon.Visible = false;
        }

        /// <summary>
        ///   Shows balloon tip with given message.
        /// </summary>
        public static void ShowBalloonTip(string message, int duration = 0)
        {
            Icon.BalloonTipText = message;
            Icon.ShowBalloonTip(duration);
        }

        /// <summary>
        /// Captures the whole screen.
        /// </summary>
        private static void Menu_CaptureScreen_Click(object sender, EventArgs e)
        {
            Manager.CaptureScreen();
        }

        /// <summary>
        /// Closes tray menu and captures the active window.
        /// </summary>
        private static void Menu_CaptureActiveWindow_Click(object sender, EventArgs e)
        {
            SendKeys.Send("%{ESC}");
            Manager.CaptureActiveWindow();
        }

        /// <summary>
        /// Captures an area on the screen.
        /// </summary>
        private static void Menu_CaptureArea_Click(object sender, EventArgs e)
        {
            Manager.CaptureArea();
        }

        /// <summary>
        /// Saves history in selected file.
        /// </summary>
        private static void Menu_SaveHistory_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();

            dialog.DefaultExt = "html";
            dialog.FileName   = Resources.Strings.HistoryFileTitle;
            dialog.Filter     = MimeTypes.DescriptionFromExtension(".html") + "|*.html";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Stream stream = dialog.OpenFile();

                if (stream != null)
                {
                    Manager.SaveHistory(stream);
                }
            }

            dialog.Dispose();
        }

        /// <summary>
        /// Updates startup value.
        /// </summary>
        private static void Menu_RunOnStartup_CheckedChanged(object sender, EventArgs e)
        {
            if (((ToolStripMenuItem)sender).Checked)
            {
                Manager.StartupRegister();
            }
            else
            {
                Manager.StartupUnregister();
            }
        }

        /// <summary>
        /// Exits program.
        /// </summary>
        private static void Menu_Exit_Click(object sender, EventArgs e)
        {
            Program.Exit();
        }

        /// <summary>
        /// Opens last URL from history in browser.
        /// </summary>
        private static void Icon_BalloonTipClicked(object sender, EventArgs e)
        {
            if ((Control.MouseButtons & MouseButtons.Left) == MouseButtons.Left)
            {
                Process.Start(History.Last().Value);
            }
        }
    }
}
