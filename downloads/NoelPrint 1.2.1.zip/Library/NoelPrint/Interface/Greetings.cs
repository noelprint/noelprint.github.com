using System;
using System.Windows.Forms;

namespace NoelPrint.Interface
{
    /// <summary>
    ///   Class to manage greetings box
    ///   on first run.
    /// </summary>
    public static class Greetings
    {
        /// <summary>
        ///   Initializes greetings window.
        /// </summary>
        static Greetings()
        {
            
        }

        /// <summary>
        ///   Shows greetings window.
        /// </summary>
        public static void Show()
        {
            
        }
    }
}
