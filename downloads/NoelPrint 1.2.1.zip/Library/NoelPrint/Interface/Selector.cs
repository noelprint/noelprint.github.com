using System;
using System.Drawing;
using System.Windows.Forms;
using Utilities;

namespace NoelPrint.Interface
{
    public delegate void SelectorEventHandler(object sender, SelectorEventArgs e);

    /// <summary>
    ///   Allows user to select an area on the screen.
    /// </summary>
    public static class Selector
    {
        private static bool              Dragged;
        private static SelectorForm      Form;
        private static BufferedGraphics  Buffer;
        private static Pen               Pen;
        private static SolidBrush        Brush;
        private static Point             StartPoint;
        private static Point             EndPoint;
        private static Bitmap            Capture;

        public static event SelectorEventHandler SelectionDone;

        /// <summary>
        ///   Initializes properties.
        /// </summary>
        static Selector()
        {
            Dragged = false;
            Form    = new SelectorForm();

            Rectangle bounds = Screen.FromControl(Form).Bounds;

            Form.ShowInTaskbar   = false;
            Form.FormBorderStyle = FormBorderStyle.None;
            Form.Left            = 0;
            Form.Top             = 0;
            Form.Width           = bounds.Width;
            Form.Height          = bounds.Height;
            Form.Cursor          = Resources.Cursor;
            Form.TopMost         = true;

            Buffer = BufferedGraphicsManager.Current.Allocate(
                Form.CreateGraphics(),
                new Rectangle(Form.Left, Form.Top, Form.Width, Form.Height)
            );

            Pen        = new Pen(Color.Red);
            Brush      = new SolidBrush(Color.FromArgb(127, Color.White));
            StartPoint = Point.Empty;
            EndPoint   = Point.Empty;
        }

        /// <summary>
        ///   Shows selector, draws area and adds event handlers.
        /// </summary>
        public static void Show()
        {
            if (Form.Visible)
            {
                return;
            }

            Capture = Printer.CaptureScreen();

            Form.Show();

            Draw();

            Form.KeyUp     += new KeyEventHandler(Form_KeyUp);
            Form.MouseDown += new MouseEventHandler(Form_MouseDown);
            Form.MouseMove += new MouseEventHandler(Form_MouseMove);
            Form.MouseUp   += new MouseEventHandler(Form_MouseUp);
        }

        /// <summary>
        ///   Hides selector, empty points removes event handlers.
        /// </summary>
        public static void Hide()
        {
            Form.Hide();

            StartPoint = Point.Empty;
            EndPoint   = Point.Empty;

            Form.KeyUp     -= Form_KeyUp;
            Form.MouseDown -= Form_MouseDown;
            Form.MouseMove -= Form_MouseMove;
            Form.MouseUp   -= Form_MouseUp;
        }

        /// <summary>
        ///   Fires selection done event if exists.
        /// </summary>
        private static void OnSelectionDone(SelectorEventArgs e)
        {
            if (SelectionDone == null)
            {
                return;
            }
            
            SelectionDone(null, e);
        }

        /// <summary>
        ///   Hides form on escape.
        /// </summary>
        private static void Form_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Escape)
            {
                return;
            }

            Dragged = false;

            Hide();
        }

        /// <summary>
        ///   Decides whether the user is dragging or not
        ///   and initializes start point.
        /// </summary>
        private static void Form_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Dragged = true;
            }

            StartPoint.X = e.X;
            StartPoint.Y = e.Y;
        }

        /// <summary>
        ///   Draws selected rectangle on screen if dragged.
        /// </summary>
        private static void Form_MouseMove(object sender, MouseEventArgs e)
        {
            if (!Dragged)
            {
                return;
            }

            EndPoint.X = e.X;
            EndPoint.Y = e.Y;

            Draw();
        }

        /// <summary>
        ///   Stops dragging, clears screen and fires event.
        /// </summary>
        private static void Form_MouseUp(object sender, MouseEventArgs e)
        {
            if (!Dragged)
            {
                return;
            }

            Dragged = false;

            EndPoint.X = e.X;
            EndPoint.Y = e.Y;

            Rectangle rectangle = MakeRectangle();

            Hide();

            if (rectangle.Width == 0 && rectangle.Height == 0)
            {
                return;
            }
            
            OnSelectionDone(new SelectorEventArgs(rectangle));
        }

        private static void Draw()
        {
            Rectangle rectangle = MakeRectangle();

            Buffer.Graphics.Clear(Color.Transparent);
            Buffer.Graphics.DrawImage(Capture, Point.Empty);

            Region region = new Region(Form.ClientRectangle);

            region.Xor(rectangle);

            Buffer.Graphics.FillRegion(Brush, region);
            Buffer.Graphics.DrawRectangle(Pen, rectangle);

            Buffer.Render();
        }

        /// <summary>
        ///   Makes a well formed rectangle from start and end points.
        /// </summary>
        private static Rectangle MakeRectangle()
        {
            return new Rectangle(
                Math.Min(StartPoint.X, EndPoint.X),
                Math.Min(StartPoint.Y, EndPoint.Y),
                Math.Abs(EndPoint.X - StartPoint.X),
                Math.Abs(EndPoint.Y - StartPoint.Y)
            );
        }

        /// <summary>
        ///   Transparent form class for selector.
        /// </summary>
        private class SelectorForm : Form
        {
            /// <summary>
            ///   Do not allow the background to be painted
            /// </summary>
            protected override void OnPaintBackground(PaintEventArgs pevent)
            {
                return;
            }
        }
    }

    /// <summary>
    ///   Event arguments class for selector events.
    /// </summary>
    public class SelectorEventArgs : EventArgs
    {
        public Rectangle Rectangle;

        /// <summary>
        ///   Sets given rectangle property.
        /// </summary>
        public SelectorEventArgs(Rectangle rectangle)
        {
            Rectangle = rectangle;
        }
    }
}
