using System;
using System.Windows.Forms;

namespace NoelPrint.Interface
{
    /// <summary>
    ///   Provides some functionalities
    ///   to display alert messages.
    /// </summary>
    public static class Alerter
    {
        /// <summary>
        ///   Displays an error message.
        /// </summary>
        public static void Error(string message)
        {
            Show(message, MessageBoxIcon.Error);
        }

        /// <summary>
        ///   Displays an exclamation message.
        /// </summary>
        public static void Exclamation(string message)
        {
            Show(message, MessageBoxIcon.Exclamation);
        }

        /// <summary>
        ///   Displays a question message.
        /// </summary>
        public static void Question(string message)
        {
            Show(message, MessageBoxIcon.Question);
        }

        /// <summary>
        ///   Displays an information message.
        /// </summary>
        public static void Information(string message)
        {
            Show(message, MessageBoxIcon.Information);
        }

        /// <summary>
        ///   Shows message with given icon.
        /// </summary>
        private static void Show(string message, MessageBoxIcon icon)
        {
            MessageBox.Show(message, Resources.Strings.Name, MessageBoxButtons.OK, icon);
        }
    }
}
