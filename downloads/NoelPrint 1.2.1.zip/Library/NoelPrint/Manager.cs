using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using NoelPrint.Interface;
using Utilities;

namespace NoelPrint
{
    /// <summary>
    ///   Wraps application functionnalities and behavior.
    /// </summary>
    public static class Manager
    {
        private static string AssemblyLocation;

        /// <summary>
        ///   Sets event handlers.
        /// </summary>
        static Manager()
        {
            AssemblyLocation = System.Reflection.Assembly.GetExecutingAssembly().Location;
            Selector.SelectionDone += new SelectorEventHandler(Selector_SelectionDone);
        }

        /// <summary>
        ///   Captures the whole screen.
        /// </summary>
        public static void CaptureScreen()
        {
            Manager.ProcessImage(Printer.CaptureScreen());
        }

        /// <summary>
        ///   Captures the active window.
        /// </summary>
        public static void CaptureActiveWindow()
        {
            Manager.ProcessImage(Printer.CaptureActiveWindow());
        }

        /// <summary>
        ///   Captures an area on the screen.
        /// </summary>
        public static void CaptureArea()
        {
            Selector.Show();
        }

        /// <summary>
        ///   Saves history as HTML into given stream.
        /// </summary>
        public static void SaveHistory(Stream stream)
        {
            string html = "<!doctype html>"          + Environment.NewLine
                        + "<html>"                   + Environment.NewLine
                        + "<head>"                   + Environment.NewLine
                        + "<meta charset=\"utf-8\">" + Environment.NewLine
                        + "</head>"                  + Environment.NewLine
                        + "<body>"                   + Environment.NewLine;

            html += "<h1>" + Resources.Strings.HistoryFileTitle + "</h1>" + Environment.NewLine
                 +  "<ul>" + Environment.NewLine;

            foreach (HistoryItem item in History.GetCollection())
            {
                html += "<li><a href=\"" + item.Value + "\">" + item.DateTime.ToString("dd MMMM yyyy HH:mm:ss") + "</a></li>";
            }

            html += "</ul>" + Environment.NewLine
                 +  "</body>" + Environment.NewLine
                 +  "</html>" + Environment.NewLine;

            StreamWriter writer = new StreamWriter(stream, Encoding.UTF8);

            writer.Write(html);

            writer.Close();
            stream.Close();
        }

        /// <summary>
        ///   Returns whether application is registered on startup.
        /// </summary>
        public static bool StartupRegistered()
        {
            return StartupManager.Registered(Resources.Strings.Name, AssemblyLocation);
        }

        /// <summary>
        ///   Registers application on startup.
        /// </summary>
        public static void StartupRegister()
        {
            StartupManager.Register(Resources.Strings.Name, AssemblyLocation);
        }

        /// <summary>
        ///   Unregisters application on startup.
        /// </summary>
        public static void StartupUnregister()
        {
            StartupManager.Unregister(Resources.Strings.Name);
        }

        /// <summary>
        ///   Fired when user has finished to select an area,
        ///   captures given area and uploads it.
        /// </summary>
        private static void Selector_SelectionDone(object sender, SelectorEventArgs e)
        {
            Manager.ProcessImage(Printer.CaptureArea(e.Rectangle));
        }

        /// <summary>
        ///   Uploads image, add it in history and shows balloon tip,
        ///   or shows error message if upload failed.
        /// </summary>
        private static void ProcessImage(Image image)
        {
            string url = Uploader.Upload(image, Resources.Strings.Name, ImageFormat.Png);

            if (url == null)
            {
                Alerter.Error(Resources.Strings.UploadError);

                return;
            }

            History.Add(url);
            Clipboard.SetText(url);
            SystemSounds.Beep.Play();
            TrayIcon.ShowBalloonTip(Resources.Strings.UploadSuccess);
        }
    }
}
