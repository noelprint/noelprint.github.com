using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Utilities;

namespace NoelPrint
{
    /// <summary>
    ///   Class to wrap compiled resources.
    /// </summary>
    public static class Resources
    {
        public static readonly string ConfigurationPath;
        public static readonly Icon   Icon;
        public static readonly Cursor Cursor;

        /// <summary>
        ///   Initializes properties.
        /// </summary>
        static Resources()
        {
            string path = Environment.GetFolderPath(
                Environment.SpecialFolder.ApplicationData);

            ConfigurationPath = path + "\\" + Strings.Name;

            ResourceManager manager = new ResourceManager(Strings.Name, Assembly.GetEntryAssembly());

            Icon = Icon.FromHandle((new Bitmap(manager.GetStream("Icon"))).GetHicon());

            string temp = Path.GetTempFileName();

            try
            {
                Save(manager.GetStream("Cursor"), temp);
                Cursor = new Cursor(LoadCursorFromFile(temp));
            }
            catch
            {
                Cursor = Cursors.Cross;
            }
            finally
            {
                File.Delete(temp);
            }

            manager.ReleaseAllResources();
        }

        /// <summary>
        ///   Saves given stream to file.
        /// </summary>
        private static void Save(Stream stream, string path)
        {
            FileStream file = File.Create(path);
            stream.CopyTo(file);
            stream.Close();
            file.Close();
        }

        [DllImport("user32.dll")]
        private static extern IntPtr LoadCursorFromFile(string lpFileName);
        
        /// <summary>
        ///   Application strings.
        /// </summary>
        public static class Strings
        {
            public static readonly string Name                = "NoelPrint";
            public static readonly string Version             = "1.2.1";
            public static readonly string HistoryFileTitle    = "Historique " + Name;
            public static readonly string CaptureScreen       = "Capturer l'écran";
            public static readonly string CaptureActiveWindow = "Capturer la fenêtre active";
            public static readonly string CaptureArea         = "Capturer une région";
            public static readonly string SaveHistory         = "Sauvegarder l'historique";
            public static readonly string RunOnStartup        = "Lancer au démarrage";
            public static readonly string Exit                = "Quitter";
            public static readonly string UploadSuccess       = "L'image a bien été mise en ligne !";
            public static readonly string UploadError         = "Une erreur est survenue lors du téléversement.";
        }
    }
}
